package play_emoji.mardomsara.com.myapplication;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Hamid on 2/4/2016.
 */
public class TextParser {

    TextParser(){

    }

    public static class Lexing {
        String text;
        int index =0;
        int lastChunkIndex = 0;
        int txtLen =0;
        List<LexEntry> chunks = new ArrayList<>();

        //For GC optimize
        char chr ;
//        String word;

        public Lexing(String txt) {
            text = txt;
            txtLen = txt.length();
        }

        public void parse(){
            for ( ; index < txtLen ; ){
                chr = text.charAt(index);
                switch(chr){
                    case '#':
                        if(isStartOfPrimeWord()){
                            foundHash();
                        }
                        break;

                    case '@':
//                        Log.d("parser", Character.toString(chr));
                        if(isStartOfPrimeWord()){
                            foundUseName();
                        }
                        break;
                }
                index++;
            }
            addCurrentText();//last text
        }

        void foundHash(){
            addCurrentText();
            String word = takeWord();
            LexEntry obj = new LexEntry();
            obj.text = word;
            obj.type = TextType.Tag;

            chunks.add(obj);
        }
        void foundUseName(){
            addCurrentText();
            String word = takeWord();
            Log.d("parser", word);
            LexEntry obj = new LexEntry();
            obj.text = word;
            obj.type = TextType.UserName;
            chunks.add(obj);

        }

        //its a prime word if: has previous space and hase at leat to char: " #a"
        boolean isStartOfPrimeWord(){
            if(index >= txtLen || isSpace(text.charAt(index+1))){
                return false;
            }

            //just not 'Exeption' break next if
            if (index == 0){
                return true;
            }

            if (isSpace(text.charAt(index-1))){
                return true;
            }
            return false;
        }

        void addCurrentText(){
            StringBuffer str = new StringBuffer();
            while(lastChunkIndex < index && lastChunkIndex < txtLen){
                str.append(text.charAt(lastChunkIndex));
                lastChunkIndex += 1;
            }

            LexEntry obj = new LexEntry();
            obj.text = str.toString();
            obj.type = TextType.SimpleText;

            chunks.add(obj);
        }

        //return and change state: '#tags' or '@kjkj'
        String takeWord(){
            StringBuffer str = new StringBuffer();
            while(index < txtLen && !isSpace(text.charAt(index))){
                str.append(text.charAt(index));
                index += 1;
            }
            lastChunkIndex = index;
            return str.toString();
        }

        boolean isSpace(char chr){
            switch(chr){
                case ' ':
                case '\t':
                case '\n':
//                case '\v':
                case '\f':
                case '\r':
                    return true;
//                    break;
                default:
                    return false;
            }
        }

    }

    public static class LexEntry {
        public String text;
        public TextType type;

    }

    public static enum TextType{
        SimpleText,
        Tag,
        UserName
    }
}
