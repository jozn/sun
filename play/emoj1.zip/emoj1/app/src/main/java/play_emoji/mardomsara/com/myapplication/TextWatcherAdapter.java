package play_emoji.mardomsara.com.myapplication;

/**
 * Created by Hamid on 1/31/2016.
 */

import android.text.Editable;
import android.text.TextWatcher;

/**
 * @author Hieu Rocker (rockerhieu@gmail.com).
 */
public class TextWatcherAdapter implements TextWatcher {
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override
    public void afterTextChanged(Editable s) {
    }
}
